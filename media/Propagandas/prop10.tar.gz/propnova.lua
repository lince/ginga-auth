local img   = canvas:new('propmedia/Prop2.png')
local dx,dy = img:attrSize()
local fundo = {img=img,x=0,y=0,dx=dx,dy=dy}

local img1   = canvas:new('propmedia/roupas70.png')
local dx,dy = img:attrSize()
local foto = {img1=img1,x=10,y=0,dx=dx,dy=dy}


local menorsz=20

function desenhafundo()
	canvas:attrColor('white')
	canvas:drawRect('fill', 0, 0, 640, 70 )
	canvas:compose(fundo.x,fundo.y,fundo.img)
	canvas:compose(foto.x,foto.y,foto.img1)
	canvas:flush()
end

function calculasz( t, sz)
	canvas:attrColor('black')
	canvas:attrFont('vera',sz)
	tx,ty = canvas:measureText(t)

	while (tx >= (520))do
			sz=sz-1
			canvas:attrFont('vera',sz)
			tx,ty = canvas:measureText(t)
	end

	if (sz<menorsz)then
		menorsz=sz
	end
end

function escrevetexto( t, szf, x, y)
	canvas:attrColor('black')
	canvas:attrFont('vera',szf)
	canvas:drawText( x, y, t)
	canvas:flush()
return sz
end


frase1="compra e venda de roupas novas, seminovas e acessorios."
frase2="grifes nacionais e importadas. aluguel de roupas de epoca. otimos precos."
frase3="localizado em frente a praca benedito calixto em pinheiros."

calculasz(frase1,20)
calculasz(frase2,20)
calculasz(frase3,20)

l1=2
l2=l1+20
l3=l2+menorsz

while (l3 > 300)do
	menorsz = menorsz-1

	l2=l1+20
	l3=l2+menorsz
end

desenhafundo()
escrevetexto(frase1,17,125,l1)
escrevetexto(frase2,menorsz,125,l2)
escrevetexto(frase3,menorsz,125,l3)
