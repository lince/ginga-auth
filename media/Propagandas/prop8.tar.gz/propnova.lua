local img   = canvas:new('propmedia/Prop5.png')
local dx,dy = img:attrSize()
local fundo = {img=img,x=0,y=380,dx=dx,dy=dy}

local img1   = canvas:new('propmedia/advogado.png')
local dx,dy = img:attrSize()
local foto = {img1=img1,x=528,y=381,dx=dx,dy=dy}


local menorsz=20

function desenhafundo()
	canvas:attrColor('black')
	canvas:drawRect('fill', 12, 420, 640, 480 )
	canvas:compose(fundo.x,fundo.y,fundo.img)
	canvas:compose(foto.x,foto.y,foto.img1)
	canvas:flush()
end

function calculasz( t, sz)
	canvas:attrColor('white')
	canvas:attrFont('vera',sz)
	tx,ty = canvas:measureText(t)

	while (tx >= (fundo.dx-200))do
			sz=sz-1
			canvas:attrFont('vera',sz)
			tx,ty = canvas:measureText(t)
	end

	if (sz<menorsz)then
		menorsz=sz
	end
end

function escrevetexto( t, szf, x, y)
	canvas:attrColor('white')
	canvas:attrFont('vera',szf)
	canvas:drawText( x, y, t)
	canvas:flush()
return sz
end



frase1="composto por profissionais voltados a todas as areas do direito"
frase2="notadamente familia e sucessoes, civil,"
frase3="penal (mesmo inquerito administrativo),"
frase4="publico e trabalhista. oab/sp 48321."

calculasz(frase1,20)
calculasz(frase2,20)
calculasz(frase3,20)

l1=395
l2=420
l3=l2+menorsz
l4=l3+menorsz

while (l4 > 470)do
	menorsz = menorsz-1
	l3=l2+menorsz
	l4=l3+menorsz
end

desenhafundo()
escrevetexto(frase1,15,23,l1)
escrevetexto(frase2,menorsz,17,l2)
escrevetexto(frase3,menorsz,17,l3)
escrevetexto(frase4,menorsz,17,l4)
