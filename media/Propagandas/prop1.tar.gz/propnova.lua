local img   = canvas:new('propmedia/Prop3.png')
local dx,dy = img:attrSize()
local fundo = {img=img,x=0,y=400,dx=dx,dy=dy}

local menorsz=20

function desenhafundo()
	canvas:compose(fundo.x,fundo.y,fundo.img)
	canvas:flush()
end

function calculasz( t, sz)
	canvas:attrColor('white')
	canvas:attrFont('vera',sz)
	tx,ty = canvas:measureText(t)

	while (tx >= (fundo.dx-40))do
			sz=sz-1
			canvas:attrFont('vera',sz)
			tx,ty = canvas:measureText(t)
	end

	if (sz<menorsz)then
		menorsz=sz
	end
end

function escrevetexto( t, szf, x, y)
	canvas:attrColor('white')
	canvas:attrFont('vera',szf)
	canvas:drawText( x, y, t)
	canvas:flush()
return sz
end

frase1="Colonia de ferias"
frase2="Temporada de ferias julho de 2003 no acampamento casa de chocolate em vinhedo, SP"
frase3="Com grande estrutura de lazer e completa programacao para criancas e jovens"

calculasz(frase1,20)
calculasz(frase2,20)
calculasz(frase3,20)

l1=420
l2=l1+20
l3=l2+menorsz

while (l3 > 470)do
	menorsz = menorsz-1

	l2=l1+20
	l3=l2+menorsz

end

desenhafundo()
escrevetexto(frase1,20,40,l1)
escrevetexto(frase2,menorsz,30,l2)
escrevetexto(frase3,menorsz,30,l3)
