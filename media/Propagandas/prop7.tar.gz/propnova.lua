local img   = canvas:new('propmedia/Prop3.png')
local dx,dy = img:attrSize()
local fundo = {img=img,x=0,y=400,dx=dx,dy=dy}

local menorsz=20

function desenhafundo()
	canvas:compose(fundo.x,fundo.y,fundo.img)
	canvas:flush()
end

function calculasz( t, sz)
	canvas:attrColor('white')
	canvas:attrFont('vera',sz)
	tx,ty = canvas:measureText(t)

	while (tx >= (fundo.dx-50))do
			sz=sz-1
			canvas:attrFont('vera',sz)
			tx,ty = canvas:measureText(t)
	end

	if (sz<menorsz)then
		menorsz=sz
	end
end

function escrevetexto( t, szf, x, y)
	canvas:attrColor('white')
	canvas:attrFont('vera',szf)
	canvas:drawText( x, y, t)
	canvas:flush()
return sz
end

frase1="Bolo Decorado"
frase2="Conheca os incriveis bolos e minibolos decorados. coberto com pasta americana"
frase3="todos os enfeites sao comestiveis."
frase4="Sao bolos personalizados que tornam sua festa ainda mais especial"

calculasz(frase1,20)
calculasz(frase2,20)
calculasz(frase3,20)
calculasz(frase4,20)

l1=420
l2=l1+15
l3=l2+menorsz
l4=l3+menorsz

while (l4 > 465)do
	menorsz = menorsz-1

	l2=l1+20
	l3=l2+menorsz
	l4=l3+menorsz
end

desenhafundo()
escrevetexto(frase1,15,40,l1)
escrevetexto(frase2,menorsz,30,l2)
escrevetexto(frase3,menorsz,30,l3)
escrevetexto(frase4,menorsz,30,l4)
