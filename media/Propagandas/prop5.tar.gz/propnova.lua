local img   = canvas:new('propmedia/Prop1.png')
local dx,dy = img:attrSize()
local fundo = {img=img,x=0,y=400,dx=dx,dy=dy}

local menorsz=20

function desenhafundo()
	canvas:compose(fundo.x,fundo.y,fundo.img)
	canvas:flush()
end

function calculasz( t, sz)
	canvas:attrColor('white')
	canvas:attrFont('vera',sz)
	tx,ty = canvas:measureText(t)

	while (tx >= (fundo.dx-50))do
			sz=sz-1
			canvas:attrFont('vera',sz)
			tx,ty = canvas:measureText(t)
	end

	if (sz<menorsz)then
		menorsz=sz
	end
end

function escrevetexto( t, szf, x, y)
	canvas:attrColor('white')
	canvas:attrFont('vera',szf)
	canvas:drawText( x, y, t)
	canvas:flush()
return sz
end

frase1="Agasalhos Esportivos"
frase2="Aqui tudo original! Loja especializada em artigos esportivos."
frase3="Temos camisas de times,chuteiras,bolas,agasalhos,uniformes,etc."
frase4="Todos os produtos sao oficiais. revendedora da nike,mizuno e outras."

calculasz(frase1,20)
calculasz(frase2,20)
calculasz(frase3,20)
calculasz(frase4,20)

l1=395
l2=420
l3=l2+menorsz
l4=l3+menorsz

while (l4 > 470)do
	menorsz = menorsz-1

	l2=420
	l3=l2+menorsz
	l4=l4+menorsz
end

desenhafundo()
escrevetexto(frase1,20,30,l1)
escrevetexto(frase2,menorsz,30,l2)
escrevetexto(frase3,menorsz,30,l3)
escrevetexto(frase4,menorsz,30,l4)
